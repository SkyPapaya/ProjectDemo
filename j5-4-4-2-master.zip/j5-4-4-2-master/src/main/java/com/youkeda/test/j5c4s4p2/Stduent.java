package com.youkeda.test.j5c4s4p2;

public class Stduent {
    public static void main(String[] args) {
        RestaurantGuide rg = new RestaurantGuide();


    }
}
