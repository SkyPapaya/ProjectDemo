package com.youkeda.test.j5c4s4p2;

public interface Food {
    public String getName();
}
