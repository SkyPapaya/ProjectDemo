package com.youkeda.test.j5c4s4p2;

public class Beef extends AbstractFood {

}
