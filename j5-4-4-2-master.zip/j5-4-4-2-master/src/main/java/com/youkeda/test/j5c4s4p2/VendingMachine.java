package com.youkeda.test.j5c4s4p2;

/**
 * 自动贩卖机
 */
public class VendingMachine {

}
