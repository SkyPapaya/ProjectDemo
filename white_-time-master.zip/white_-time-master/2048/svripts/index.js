let grid = new Grid();
let tile = new Tile(
  {
    row: 0,
    column: 0
  },
  2
);
grid.add(tile);
console.log(grid);
