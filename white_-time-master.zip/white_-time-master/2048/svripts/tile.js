function Tile(position, value) {
    this.row = position.row;
    this.column = position.column;
    this.value = value;
  }
  