package service;

import model.Subject;

import java.util.List;

/**
 * @author whm89
 */
public interface SbujectSrevice {
    Subject list(String subjectId);


}
